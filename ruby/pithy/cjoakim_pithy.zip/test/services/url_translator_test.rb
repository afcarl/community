require 'test_helper'

# rake test test/services/url_translator_test.rb

class UrlTranslationTest < ActiveSupport::TestCase

  test 'shorten method' do
    assert_equal(0, UrlTranslation.count)

    hash1 = UrlTranslator.new.shorten('www.google.com')
    assert_valid_url_translation_hash(hash1)
    assert_equal(1, UrlTranslation.count)

    hash2 = UrlTranslator.new.shorten('www.google.com')
    assert_valid_url_translation_hash(hash2)
    assert_equal(1, UrlTranslation.count)
    assert_equal(hash1, hash2)

    hash3 = UrlTranslator.new.shorten('decisiv.com')
    assert_valid_url_translation_hash(hash3)
    assert_equal(2, UrlTranslation.count)

    book_url = "http://www.amazon.com/Rails-Way-Addison-Wesley-Professional-Ruby/dp/0321944275/ref=sr_1_1?ie=UTF8&qid=1441968110&sr=8-1&keywords=the+rails+way"
    hash4 = UrlTranslator.new.shorten(book_url)
    assert_valid_url_translation_hash(hash4)
    assert_equal(3, UrlTranslation.count)
    
  end

  test 'lengthen method' do
    assert_equal(0, UrlTranslation.count)

    hash1 = UrlTranslator.new.shorten('www.google.com')
    assert_valid_url_translation_hash(hash1)
    assert_equal(1, UrlTranslation.count)

    short_url = hash1['short_url']

    hash2 = UrlTranslator.new.lengthen(short_url)
    assert_valid_url_translation_hash(hash2)
    assert_equal(1, UrlTranslation.count)
    assert_equal('www.google.com', hash2['long_url'])

    hash3 = UrlTranslator.new.lengthen('oops')
    assert_valid_url_translation_hash(hash3)
    assert_equal(1, UrlTranslation.count)
    assert_equal('oops', hash3['short_url'])
    assert_equal(nil,    hash3['long_url'])
  end

  test 'inappropriate_words method' do
    assert_equal(["foo", "bar", "hack"], UrlTranslator.inappropriate_words)
  end

  test 'inappropriate? variable' do
    ut = UrlTranslator.new
    assert_equal(false, ut.send(:inappropriate?, 'nuicqns8'))
    assert_equal(true,  ut.send(:inappropriate?, 'nuhacks8'))
  end
end
