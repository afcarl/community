require 'simplecov'
SimpleCov.start 'rails' do
  add_group  'Services',  'app/services'
  add_group  'Libraries', 'lib/'
  add_filter 'test/'
  add_filter 'vendor/'
end

ENV['RAILS_ENV'] ||= 'test'
require File.expand_path('../../config/environment', __FILE__)
require 'rails/test_help'

class ActiveSupport::TestCase
  # Setup all fixtures in test/fixtures/*.yml for all tests in alphabetical order.
  fixtures :all

  def assert_valid_url_translation_hash(hash)
    assert_instance_of(Hash, hash)
    assert_equal(2, hash.size)
    assert(hash.has_key?('long_url'))
    assert(hash.has_key?('short_url'))
  end
end
