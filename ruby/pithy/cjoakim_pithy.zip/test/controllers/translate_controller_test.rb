require 'test_helper'

class TranslateControllerTest < ActionController::TestCase

  test "should not accept a HTTP GET request to shorten" do
    get :shorten
    assert_response 400
  end

  test "should not accept a HTTP GET request to lengthen" do
    get :lengthen
    assert_response 400
  end

  test "should not accept invalid POST args to shorten" do
    post :shorten, {}
    assert_response 400

    post :shorten, {url: nil}
    assert_response 400

    post :shorten, {url: '2sht'}
    assert_response 400
  end

  test "should not accept invalid POST args to lengthen" do
    post :lengthen, {}
    assert_response 400

    post :lengthen, {url: nil}
    assert_response 400

    post :lengthen, {url: '2sht'}
    assert_response 400
  end

  test "should accept valid POST args to shorten" do
    post :shorten, {url: 'www.amazon.com'}
    assert_response 200
    hash1 = JSON.parse(@response.body)
    assert_valid_url_translation_hash(hash1)
    assert_equal('www.amazon.com', hash1['long_url'])

    post :shorten, {url: 'www.amazon.com'}
    assert_response 200
    hash2 = JSON.parse(@response.body)
    assert_equal(hash1, hash2)
  end

  test "should accept valid POST args to lengthen" do
    UrlTranslation.create(long_url: "rubygems.org", short_url: "nuidkxmi")

    post :lengthen, {url: 'nuidkxmi'}
    assert_response 200
    hash1 = JSON.parse(@response.body)
    assert_valid_url_translation_hash(hash1)
    assert_equal('rubygems.org', hash1['long_url'])
    assert_equal('nuidkxmi',     hash1['short_url'])

    post :lengthen, {url: 'nuidkxmi'}
    assert_response 200
    hash2 = JSON.parse(@response.body)
    assert_equal(hash1, hash2)
  end

end
