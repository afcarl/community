#!/bin/bash

echo 'recreating the dev and test databases...'

rake db:drop
rake db:create
rake db:migrate
rake db:seed
rake db:test:prepare

echo 'done'
