class TranslateController < ApplicationController

  layout nil

  protect_from_forgery with: :null_session, only: Proc.new { |c| c.request.format.json? }
  
  def shorten
    if params_valid?
      render json: UrlTranslator.new.shorten(params[:url].strip)
    else
      render :nothing => true, :status => 400
    end
  end

  def lengthen
    if params_valid?
      render json: UrlTranslator.new.lengthen(params[:url].strip)
    else
      render :nothing => true, :status => 400
    end
  end

  private

  def params_valid?
    url = params[:url]
    return false if url.nil?
    return false if url.class.name != 'String'
    return false if url.strip.length < min_url_length
    true
  end

  def min_url_length
    5
  end

end
