class UrlTranslator < Object

  @@inappropriate_words = []

  cattr_reader :inappropriate_words

  # this method is invoked in the inappropriate_words.rb initializer
  def self.set_inappropriate_words(array)
    if array
      @@inappropriate_words = []
      array.each { | word | @@inappropriate_words << word.strip.downcase }
    end
  end

  def shorten(long_url)
    hash = {}
    hash['long_url']  = long_url
    hash['short_url'] = translate_to_short(long_url)
    hash
  end

  def lengthen(short_url)
    hash = {}
    hash['short_url'] = short_url
    hash['long_url']  = translate_to_long(short_url)
    hash
  end

  private

  def translate_to_short(long_url)
    ut = UrlTranslation.find_by_long_url(long_url)
    if ut
      ut.short_url
    else
      create_translation(long_url)
    end
  end

  def create_translation(long_url)
    while true do 
      s  = Time.now.to_i.to_s(36)
      s  = disambiguate(s)
      unless inappropriate?(s)
        ut = UrlTranslation.find_by_short_url(s)
        if ut.nil?
          ut = UrlTranslation.create(long_url: long_url, short_url: s)
          return ut.short_url
        end
      end
    end
  end

  def translate_to_long(short_url)
    ut = UrlTranslation.find_by_short_url(short_url)
    if ut
      ut.long_url
    else
      nil
    end
  end

  def disambiguate(s)
    s = s + random_suffix
    disambiguate_character_pairs.each do | pair |
      s = s.tr(pair[0], pair[1])
    end
    s
  end

  def disambiguate_character_pairs
    list = []
    list << ['0', 'O']
    list
  end

  def random_suffix
    (Time.now.to_i - 1239).to_s(36).last(2)
  end

  def inappropriate?(s)
    downcased = s.downcase
    @@inappropriate_words.each do | word |
      if downcased.include?(word)
        return true
      end
    end
    false
  end

end
