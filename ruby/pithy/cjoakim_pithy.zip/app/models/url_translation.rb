class UrlTranslation < ActiveRecord::Base
  
end
