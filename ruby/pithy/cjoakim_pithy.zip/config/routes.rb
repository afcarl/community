Rails.application.routes.draw do

  post 'shorten_url'  => 'translate#shorten',  :constraints => { :format => 'json' }
  post 'lengthen_url' => 'translate#lengthen', :constraints => { :format => 'json' }

end
