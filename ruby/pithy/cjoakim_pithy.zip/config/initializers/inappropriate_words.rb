
UrlTranslator.set_inappropriate_words %w( foo bar hack )
