class CreateUrlTranslations < ActiveRecord::Migration

  def change
    create_table :url_translations do |t|
      t.string   :long_url
      t.string   :short_url

      t.timestamps null: false
    end

    add_index(:url_translations, :long_url,  {unique: true })
    add_index(:url_translations, :short_url, {unique: true })
  end

end
