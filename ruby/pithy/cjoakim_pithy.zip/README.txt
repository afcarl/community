README

Candidate:
  Chris Joakim, Davidson, NC
  christopher.joakim@gmail.com
  704-896-2098

Setup:
  This solution uses a sqlite3 database.

  unzip the solution zip-file (i.e. - cjoakim_pithy_20150911_0753.zip)
  to an empty directory on your hard drive.

  $ gem install bundler
  $ bundle install

  $ rake db:drop
  $ rake db:create
  $ rake db:migrate
  $ rake db:seed
  $ rake db:test:prepare

  - or -

  $ chmod 744 db_setup.sh
  $ ./db_setup.sh

Tests:
  $ rake test

Test Coverage:
  Open file coverage/index.html in your browser.
  See 100% coverage per SimpleCov reporting.

Localhost testing with curl; examples:
  $ rails s
  $ curl -v -X POST -d u=bad http://localhost:3000/shorten_url.json
  $ curl -v -X POST -d url=bad http://localhost:3000/shorten_url.json
  $ curl -v -X POST -d url=www.google.com http://localhost:3000/shorten_url.json
  $ curl -v -X POST -d url=nui7q1rm http://localhost:3000/lengthen_url.json  (change 'nui7q1rm' to short_url value)
